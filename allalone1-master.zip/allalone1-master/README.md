# poor-broken-
I need help mentally,physically,,spiritually,ect
